<?php

function hook_uc_recurring_hosted_subscription_alter(&$object) {

}

function hook_uc_recurring_hosted_subscription_save($object) {

}

function hook_uc_recurring_hosted_subscription_delete($id, $type = 'rfid') {

}
