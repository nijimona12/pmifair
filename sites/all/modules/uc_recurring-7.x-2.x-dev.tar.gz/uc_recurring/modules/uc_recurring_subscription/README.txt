uc_recurring_subscription
~~~~~~~~~~~~~~~~~~~~~~~~~

uc_recurring_subscription is a drupal module that integrates recurring payments
and roles and provides a set of features specifically designed for managing a
membership/subscription website.

INSTALL
~~~~~~~
This module requires a curenct version of ubercart, either the 2.x-dev or 2.5 (when released)

